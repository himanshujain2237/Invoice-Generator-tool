import os
from datetime import datetime, timedelta
import tkinter as tk
from tkinter import ttk, messagebox

from PIL import Image as PILImage
from PIL import ImageTk

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.platypus import (
    SimpleDocTemplate,
    Table,
    TableStyle,
    Paragraph,
    Spacer,
    Image,
    HRFlowable,
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle


# ======================================
# CONFIG
# ======================================
OUTPUT_FOLDER = "invoices"
LOGO_PATHS = [
    os.path.join("assets", "Xpensease_logo.jpg"),
    "Xpensease_logo.jpg",
]
DEFAULT_ISSUER_NAME = "Xpensease"
APP_TITLE = "Xpensease GST Invoice Generator"


# ======================================
# FONT SETUP
# ======================================
def register_fonts():
    possible_fonts = [
        ("DejaVuSans", "DejaVuSans.ttf"),
        ("ArialUnicode", "arial.ttf"),
    ]

    for font_name, font_file in possible_fonts:
        if os.path.exists(font_file):
            try:
                pdfmetrics.registerFont(TTFont(font_name, font_file))
                return font_name
            except Exception:
                pass

    try:
        pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))
        return "STSong-Light"
    except Exception:
        return "Helvetica"


# ======================================
# UTILITIES
# ======================================
def ensure_output_folder():
    os.makedirs(OUTPUT_FOLDER, exist_ok=True)


def find_logo_path():
    for path in LOGO_PATHS:
        if os.path.exists(path):
            return path
    return None


def format_currency(amount):
    return f"₹ {amount:,.2f}"


def generate_invoice_number():
    return f"INV-{datetime.now().strftime('%Y%m%d-%H%M%S')}"


def parse_float(value, field_name):
    try:
        val = float(value)
        if val < 0:
            raise ValueError
        return val
    except ValueError:
        raise ValueError(f"Invalid value for {field_name}. Please enter a valid positive number.")


# ======================================
# PDF STYLES
# ======================================
def build_styles(font_name):
    styles = getSampleStyleSheet()

    title_style = ParagraphStyle(
        "TitleStyle",
        parent=styles["Heading1"],
        fontName=font_name,
        fontSize=20,
        leading=24,
        textColor=colors.HexColor("#111111"),
        spaceAfter=8,
    )

    section_title_style = ParagraphStyle(
        "SectionTitle",
        parent=styles["Heading4"],
        fontName=font_name,
        fontSize=10,
        leading=12,
        textColor=colors.HexColor("#4B5563"),
        spaceAfter=4,
    )

    body_style = ParagraphStyle(
        "BodyStyle",
        parent=styles["BodyText"],
        fontName=font_name,
        fontSize=9,
        leading=12,
        textColor=colors.HexColor("#111827"),
    )

    label_style = ParagraphStyle(
        "LabelStyle",
        parent=styles["BodyText"],
        fontName=font_name,
        fontSize=9,
        leading=12,
        textColor=colors.HexColor("#6B7280"),
    )

    small_style = ParagraphStyle(
        "SmallStyle",
        parent=styles["BodyText"],
        fontName=font_name,
        fontSize=8,
        leading=10,
        textColor=colors.HexColor("#6B7280"),
    )

    return {
        "title": title_style,
        "section_title": section_title_style,
        "body": body_style,
        "label": label_style,
        "small": small_style,
    }


# ======================================
# PDF GENERATION
# ======================================
def generate_pdf(invoice_data, items, totals):
    ensure_output_folder()
    logo_path = find_logo_path()
    font_name = register_fonts()
    styles = build_styles(font_name)

    file_name = f"invoice_{invoice_data['invoice_number'].replace('/', '_').replace(' ', '_')}.pdf"
    output_path = os.path.join(OUTPUT_FOLDER, file_name)

    doc = SimpleDocTemplate(
        output_path,
        pagesize=A4,
        leftMargin=18 * mm,
        rightMargin=18 * mm,
        topMargin=16 * mm,
        bottomMargin=16 * mm,
    )

    elements = []

    # Header
    left_part = []
    if logo_path:
        try:
            logo = Image(logo_path, width=30 * mm, height=30 * mm)
            left_part.append(logo)
        except Exception:
            pass

    left_part.append(Spacer(1, 2 * mm))

    right_header = [
        Paragraph("<b>Tax Invoice</b>", styles["title"]),
        Paragraph(
            "<font color='#6B7280'>Professional GST Invoice • Xpensease</font>",
            styles["small"],
        ),
    ]

    header_table = Table(
        [[left_part, right_header]],
        colWidths=[50 * mm, 120 * mm],
    )
    header_table.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("ALIGN", (1, 0), (1, 0), "RIGHT"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 0),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
    ]))
    elements.append(header_table)
    elements.append(Spacer(1, 4 * mm))
    elements.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor("#D1D5DB")))
    elements.append(Spacer(1, 5 * mm))

    # Meta section
    meta_data = [
        [
            Paragraph("<b>Tax Invoice No.</b>", styles["label"]),
            Paragraph(invoice_data["invoice_number"], styles["body"]),
            Paragraph("<b>Date</b>", styles["label"]),
            Paragraph(invoice_data["invoice_date"], styles["body"]),
        ],
        [
            Paragraph("<b>Order No.</b>", styles["label"]),
            Paragraph(invoice_data["order_number"], styles["body"]),
            Paragraph("<b>Due Date</b>", styles["label"]),
            Paragraph(invoice_data["due_date"], styles["body"]),
        ],
    ]

    meta_table = Table(meta_data, colWidths=[30 * mm, 55 * mm, 25 * mm, 50 * mm])
    meta_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F9FAFB")),
        ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#E5E7EB")),
        ("INNERGRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#E5E7EB")),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    elements.append(meta_table)
    elements.append(Spacer(1, 7 * mm))

    # Issuer / Recipient
    issuer_lines = [
        Paragraph("<b>ISSUER</b>", styles["section_title"]),
        Paragraph(f"<b>{invoice_data['issuer_name']}</b>", styles["body"]),
        Paragraph(f"GST: {invoice_data['issuer_gst']}", styles["body"]),
        Paragraph(invoice_data["issuer_email"], styles["body"]),
        Paragraph(invoice_data["issuer_phone"], styles["body"]),
    ]

    recipient_lines = [
        Paragraph("<b>RECIPIENT</b>", styles["section_title"]),
        Paragraph(f"<b>{invoice_data['recipient_name']}</b>", styles["body"]),
        Paragraph(invoice_data["recipient_email"], styles["body"]),
    ]

    if invoice_data["recipient_gst"]:
        recipient_lines.append(Paragraph(f"GST: {invoice_data['recipient_gst']}", styles["body"]))

    party_table = Table([[issuer_lines, recipient_lines]], colWidths=[85 * mm, 85 * mm])
    party_table.setStyle(TableStyle([
        ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#E5E7EB")),
        ("INNERGRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#E5E7EB")),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    elements.append(party_table)
    elements.append(Spacer(1, 8 * mm))

    # Items table
    item_table_data = [[
        Paragraph("<b>Description</b>", styles["body"]),
        Paragraph("<b>Qty</b>", styles["body"]),
        Paragraph("<b>Unit Price</b>", styles["body"]),
        Paragraph("<b>GST %</b>", styles["body"]),
        Paragraph("<b>GST Amt</b>", styles["body"]),
        Paragraph("<b>Total</b>", styles["body"]),
    ]]

    for item in items:
        qty_display = int(item["quantity"]) if float(item["quantity"]).is_integer() else item["quantity"]
        item_table_data.append([
            Paragraph(item["description"], styles["body"]),
            Paragraph(str(qty_display), styles["body"]),
            Paragraph(format_currency(item["unit_price"]), styles["body"]),
            Paragraph(f"{item['gst_percent']:.2f}%", styles["body"]),
            Paragraph(format_currency(item["gst_amount"]), styles["body"]),
            Paragraph(format_currency(item["line_total"]), styles["body"]),
        ])

    item_table = Table(
        item_table_data,
        colWidths=[60 * mm, 15 * mm, 28 * mm, 18 * mm, 28 * mm, 28 * mm],
        repeatRows=1,
    )
    item_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#84CC16")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.black),
        ("ALIGN", (1, 1), (-1, -1), "RIGHT"),
        ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#D1D5DB")),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F9FAFB")]),
    ]))
    elements.append(item_table)
    elements.append(Spacer(1, 8 * mm))

    # Summary
    summary_data = [
        [Paragraph("<b>Subtotal</b>", styles["body"]), Paragraph(format_currency(totals["subtotal"]), styles["body"])],
        [Paragraph("<b>Total GST</b>", styles["body"]), Paragraph(format_currency(totals["total_gst"]), styles["body"])],
        [Paragraph("<b>Grand Total</b>", styles["body"]), Paragraph(f"<b>{format_currency(totals['grand_total'])}</b>", styles["body"])],
    ]

    summary_table = Table(summary_data, colWidths=[40 * mm, 40 * mm], hAlign="RIGHT")
    summary_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 1), colors.HexColor("#F9FAFB")),
        ("BACKGROUND", (0, 2), (-1, 2), colors.HexColor("#E5F7EA")),
        ("BOX", (0, 0), (-1, -1), 0.8, colors.HexColor("#D1D5DB")),
        ("INNERGRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#D1D5DB")),
        ("ALIGN", (1, 0), (1, -1), "RIGHT"),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
    ]))
    elements.append(summary_table)
    elements.append(Spacer(1, 10 * mm))

    # Footer
    elements.append(HRFlowable(width="100%", thickness=0.6, color=colors.HexColor("#E5E7EB")))
    elements.append(Spacer(1, 4 * mm))
    elements.append(Paragraph("Thank you for your business.", styles["small"]))
    elements.append(Paragraph("Generated by Xpensease", styles["small"]))

    doc.build(elements)
    return output_path


# ======================================
# GUI APP
# ======================================
class InvoiceApp:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("1200x760")
        self.root.configure(bg="#F3F4F6")

        self.logo_img = None

        self.setup_styles()
        self.build_ui()
        self.load_defaults()
        self.load_logo_preview()

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use("clam")

        style.configure("TFrame", background="#F3F4F6")
        style.configure("Card.TFrame", background="white")
        style.configure("Header.TLabel", background="#F3F4F6", foreground="#111827", font=("Segoe UI", 18, "bold"))
        style.configure("SubHeader.TLabel", background="#F3F4F6", foreground="#6B7280", font=("Segoe UI", 10))
        style.configure("Section.TLabelframe", background="white")
        style.configure("Section.TLabelframe.Label", background="white", foreground="#111827", font=("Segoe UI", 10, "bold"))
        style.configure("TLabel", background="white", foreground="#111827", font=("Segoe UI", 9))
        style.configure("TEntry", padding=5)
        style.configure("Accent.TButton", background="#84CC16", foreground="black", font=("Segoe UI", 10, "bold"))
        style.map("Accent.TButton", background=[("active", "#65A30D")])

    def build_ui(self):
        # Main container
        main = ttk.Frame(self.root, padding=16)
        main.pack(fill="both", expand=True)

        # Header
        header_frame = ttk.Frame(main)
        header_frame.pack(fill="x", pady=(0, 12))

        self.logo_label = tk.Label(header_frame, bg="#F3F4F6")
        self.logo_label.pack(side="left", padx=(0, 12))

        text_header = ttk.Frame(header_frame)
        text_header.pack(side="left")
        ttk.Label(text_header, text="Xpensease GST Invoice Generator", style="Header.TLabel").pack(anchor="w")
        ttk.Label(text_header, text="Professional GUI Invoice Tool with PDF Export", style="SubHeader.TLabel").pack(anchor="w")

        # Scrollable-ish layout via canvas
        outer = tk.Frame(main, bg="#F3F4F6")
        outer.pack(fill="both", expand=True)

        canvas = tk.Canvas(outer, bg="#F3F4F6", highlightthickness=0)
        scrollbar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        self.scroll_frame = ttk.Frame(canvas)

        self.scroll_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=self.scroll_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Content layout
        top_row = ttk.Frame(self.scroll_frame)
        top_row.pack(fill="x", pady=(0, 10))

        left_col = ttk.Frame(top_row)
        left_col.pack(side="left", fill="both", expand=True, padx=(0, 6))

        right_col = ttk.Frame(top_row)
        right_col.pack(side="left", fill="both", expand=True, padx=(6, 0))

        # Invoice Details
        self.invoice_frame = ttk.LabelFrame(left_col, text="Invoice Details", style="Section.TLabelframe", padding=12)
        self.invoice_frame.pack(fill="x", pady=(0, 10))

        self.invoice_number_var = tk.StringVar()
        self.order_number_var = tk.StringVar()
        self.invoice_date_var = tk.StringVar()
        self.due_date_var = tk.StringVar()

        self.create_form_row(self.invoice_frame, "Invoice Number", self.invoice_number_var, 0)
        self.create_form_row(self.invoice_frame, "Order Number", self.order_number_var, 1)
        self.create_form_row(self.invoice_frame, "Invoice Date (DD/MM/YYYY)", self.invoice_date_var, 2)
        self.create_form_row(self.invoice_frame, "Due Date (DD/MM/YYYY)", self.due_date_var, 3)

        # Issuer Details
        self.issuer_frame = ttk.LabelFrame(left_col, text="Issuer Details", style="Section.TLabelframe", padding=12)
        self.issuer_frame.pack(fill="x", pady=(0, 10))

        self.issuer_name_var = tk.StringVar()
        self.issuer_gst_var = tk.StringVar()
        self.issuer_email_var = tk.StringVar()
        self.issuer_phone_var = tk.StringVar()

        self.create_form_row(self.issuer_frame, "Company Name", self.issuer_name_var, 0)
        self.create_form_row(self.issuer_frame, "GST Number", self.issuer_gst_var, 1)
        self.create_form_row(self.issuer_frame, "Email", self.issuer_email_var, 2)
        self.create_form_row(self.issuer_frame, "Phone", self.issuer_phone_var, 3)

        # Recipient Details
        self.recipient_frame = ttk.LabelFrame(right_col, text="Recipient Details", style="Section.TLabelframe", padding=12)
        self.recipient_frame.pack(fill="x", pady=(0, 10))

        self.recipient_name_var = tk.StringVar()
        self.recipient_email_var = tk.StringVar()
        self.recipient_gst_var = tk.StringVar()

        self.create_form_row(self.recipient_frame, "Recipient Name", self.recipient_name_var, 0)
        self.create_form_row(self.recipient_frame, "Recipient Email", self.recipient_email_var, 1)
        self.create_form_row(self.recipient_frame, "Recipient GST (Optional)", self.recipient_gst_var, 2)

        # Item entry section
        self.item_entry_frame = ttk.LabelFrame(right_col, text="Add Item", style="Section.TLabelframe", padding=12)
        self.item_entry_frame.pack(fill="x", pady=(0, 10))

        self.item_desc_var = tk.StringVar()
        self.item_qty_var = tk.StringVar()
        self.item_price_var = tk.StringVar()
        self.item_gst_var = tk.StringVar()

        self.create_form_row(self.item_entry_frame, "Description", self.item_desc_var, 0)
        self.create_form_row(self.item_entry_frame, "Quantity", self.item_qty_var, 1)
        self.create_form_row(self.item_entry_frame, "Unit Price", self.item_price_var, 2)
        self.create_form_row(self.item_entry_frame, "GST %", self.item_gst_var, 3)

        btn_row = ttk.Frame(self.item_entry_frame)
        btn_row.grid(row=4, column=0, columnspan=2, sticky="w", pady=(8, 0))

        ttk.Button(btn_row, text="Add Item", command=self.add_item, style="Accent.TButton").pack(side="left", padx=(0, 8))
        ttk.Button(btn_row, text="Clear Item Fields", command=self.clear_item_fields).pack(side="left")

        # Items table
        self.items_frame = ttk.LabelFrame(self.scroll_frame, text="Invoice Items", style="Section.TLabelframe", padding=12)
        self.items_frame.pack(fill="both", expand=True, pady=(0, 10))

        columns = ("description", "quantity", "unit_price", "gst_percent", "gst_amount", "total")
        self.tree = ttk.Treeview(self.items_frame, columns=columns, show="headings", height=10)
        self.tree.pack(fill="both", expand=True)

        self.tree.heading("description", text="Description")
        self.tree.heading("quantity", text="Qty")
        self.tree.heading("unit_price", text="Unit Price")
        self.tree.heading("gst_percent", text="GST %")
        self.tree.heading("gst_amount", text="GST Amt")
        self.tree.heading("total", text="Total")

        self.tree.column("description", width=280)
        self.tree.column("quantity", width=70, anchor="center")
        self.tree.column("unit_price", width=120, anchor="e")
        self.tree.column("gst_percent", width=90, anchor="center")
        self.tree.column("gst_amount", width=120, anchor="e")
        self.tree.column("total", width=140, anchor="e")

        action_row = ttk.Frame(self.items_frame)
        action_row.pack(fill="x", pady=(8, 0))

        ttk.Button(action_row, text="Remove Selected Item", command=self.remove_selected_item).pack(side="left")
        ttk.Button(action_row, text="Clear All Items", command=self.clear_all_items).pack(side="left", padx=(8, 0))

        # Totals panel
        self.totals_frame = ttk.LabelFrame(self.scroll_frame, text="Live Totals", style="Section.TLabelframe", padding=12)
        self.totals_frame.pack(fill="x", pady=(0, 10))

        self.subtotal_var = tk.StringVar(value="₹ 0.00")
        self.total_gst_var = tk.StringVar(value="₹ 0.00")
        self.grand_total_var = tk.StringVar(value="₹ 0.00")

        self.create_readonly_row(self.totals_frame, "Subtotal", self.subtotal_var, 0)
        self.create_readonly_row(self.totals_frame, "Total GST", self.total_gst_var, 1)
        self.create_readonly_row(self.totals_frame, "Grand Total", self.grand_total_var, 2)

        # Bottom buttons
        bottom_row = ttk.Frame(self.scroll_frame)
        bottom_row.pack(fill="x", pady=(0, 20))

        ttk.Button(bottom_row, text="Generate PDF Invoice", command=self.generate_invoice, style="Accent.TButton").pack(side="left")
        ttk.Button(bottom_row, text="Reset Form", command=self.reset_form).pack(side="left", padx=(10, 0))

        self.items = []

    def create_form_row(self, parent, label, variable, row):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=(0, 8), pady=5)
        entry = ttk.Entry(parent, textvariable=variable, width=36)
        entry.grid(row=row, column=1, sticky="ew", pady=5)
        parent.columnconfigure(1, weight=1)

    def create_readonly_row(self, parent, label, variable, row):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=(0, 8), pady=5)
        value_label = tk.Label(
            parent,
            textvariable=variable,
            bg="white",
            fg="#111827",
            font=("Segoe UI", 10, "bold")
        )
        value_label.grid(row=row, column=1, sticky="e", pady=5)
        parent.columnconfigure(1, weight=1)

    def load_defaults(self):
        today = datetime.today()
        due = today + timedelta(days=7)

        self.invoice_number_var.set(generate_invoice_number())
        self.order_number_var.set("-")
        self.invoice_date_var.set(today.strftime("%d/%m/%Y"))
        self.due_date_var.set(due.strftime("%d/%m/%Y"))

        self.issuer_name_var.set(DEFAULT_ISSUER_NAME)

    def load_logo_preview(self):
        logo_path = find_logo_path()
        if not logo_path:
            return

        try:
            img = PILImage.open(logo_path)
            img = img.resize((60, 60))
            self.logo_img = ImageTk.PhotoImage(img)
            self.logo_label.configure(image=self.logo_img)
        except Exception:
            pass

    def clear_item_fields(self):
        self.item_desc_var.set("")
        self.item_qty_var.set("")
        self.item_price_var.set("")
        self.item_gst_var.set("")

    def add_item(self):
        try:
            description = self.item_desc_var.get().strip()
            if not description:
                raise ValueError("Description is required.")

            quantity = parse_float(self.item_qty_var.get().strip(), "Quantity")
            unit_price = parse_float(self.item_price_var.get().strip(), "Unit Price")
            gst_percent = parse_float(self.item_gst_var.get().strip(), "GST %")

            if quantity <= 0:
                raise ValueError("Quantity must be greater than 0.")

            line_subtotal = quantity * unit_price
            gst_amount = line_subtotal * gst_percent / 100
            line_total = line_subtotal + gst_amount

            item = {
                "description": description,
                "quantity": quantity,
                "unit_price": unit_price,
                "gst_percent": gst_percent,
                "line_subtotal": line_subtotal,
                "gst_amount": gst_amount,
                "line_total": line_total,
            }

            self.items.append(item)

            qty_display = int(quantity) if float(quantity).is_integer() else quantity

            self.tree.insert(
                "",
                "end",
                values=(
                    description,
                    qty_display,
                    format_currency(unit_price),
                    f"{gst_percent:.2f}%",
                    format_currency(gst_amount),
                    format_currency(line_total),
                ),
            )

            self.update_totals()
            self.clear_item_fields()

        except Exception as e:
            messagebox.showerror("Invalid Item", str(e))

    def remove_selected_item(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("No Selection", "Please select an item to remove.")
            return

        indices = []
        for item_id in selected:
            idx = self.tree.index(item_id)
            indices.append(idx)

        for item_id in selected:
            self.tree.delete(item_id)

        for idx in sorted(indices, reverse=True):
            if 0 <= idx < len(self.items):
                self.items.pop(idx)

        self.update_totals()

    def clear_all_items(self):
        for row in self.tree.get_children():
            self.tree.delete(row)
        self.items = []
        self.update_totals()

    def calculate_totals(self):
        subtotal = sum(item["line_subtotal"] for item in self.items)
        total_gst = sum(item["gst_amount"] for item in self.items)
        grand_total = subtotal + total_gst

        return {
            "subtotal": subtotal,
            "total_gst": total_gst,
            "grand_total": grand_total,
        }

    def update_totals(self):
        totals = self.calculate_totals()
        self.subtotal_var.set(format_currency(totals["subtotal"]))
        self.total_gst_var.set(format_currency(totals["total_gst"]))
        self.grand_total_var.set(format_currency(totals["grand_total"]))

    def validate_main_fields(self):
        required = [
            ("Recipient Name", self.recipient_name_var.get().strip()),
            ("Recipient Email", self.recipient_email_var.get().strip()),
            ("Issuer Name", self.issuer_name_var.get().strip()),
            ("Issuer GST", self.issuer_gst_var.get().strip()),
            ("Issuer Email", self.issuer_email_var.get().strip()),
            ("Issuer Phone", self.issuer_phone_var.get().strip()),
            ("Invoice Number", self.invoice_number_var.get().strip()),
            ("Invoice Date", self.invoice_date_var.get().strip()),
            ("Due Date", self.due_date_var.get().strip()),
        ]

        for field_name, value in required:
            if not value:
                raise ValueError(f"{field_name} is required.")

        if not self.items:
            raise ValueError("Please add at least one invoice item.")

    def collect_invoice_data(self):
        return {
            "invoice_number": self.invoice_number_var.get().strip(),
            "order_number": self.order_number_var.get().strip() or "-",
            "invoice_date": self.invoice_date_var.get().strip(),
            "due_date": self.due_date_var.get().strip(),
            "recipient_name": self.recipient_name_var.get().strip(),
            "recipient_email": self.recipient_email_var.get().strip(),
            "recipient_gst": self.recipient_gst_var.get().strip(),
            "issuer_name": self.issuer_name_var.get().strip(),
            "issuer_gst": self.issuer_gst_var.get().strip(),
            "issuer_email": self.issuer_email_var.get().strip(),
            "issuer_phone": self.issuer_phone_var.get().strip(),
        }

    def generate_invoice(self):
        try:
            self.validate_main_fields()
            invoice_data = self.collect_invoice_data()
            totals = self.calculate_totals()

            pdf_path = generate_pdf(invoice_data, self.items, totals)

            messagebox.showinfo(
                "Success",
                f"Invoice generated successfully!\n\nSaved to:\n{pdf_path}"
            )

        except Exception as e:
            messagebox.showerror("Error", str(e))

    def reset_form(self):
        if not messagebox.askyesno("Reset Form", "Are you sure you want to reset all fields?"):
            return

        self.recipient_name_var.set("")
        self.recipient_email_var.set("")
        self.recipient_gst_var.set("")

        self.issuer_name_var.set(DEFAULT_ISSUER_NAME)
        self.issuer_gst_var.set("")
        self.issuer_email_var.set("")
        self.issuer_phone_var.set("")

        today = datetime.today()
        due = today + timedelta(days=7)

        self.invoice_number_var.set(generate_invoice_number())
        self.order_number_var.set("-")
        self.invoice_date_var.set(today.strftime("%d/%m/%Y"))
        self.due_date_var.set(due.strftime("%d/%m/%Y"))

        self.clear_item_fields()
        self.clear_all_items()


# ======================================
# MAIN
# ======================================
def main():
    root = tk.Tk()
    app = InvoiceApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()